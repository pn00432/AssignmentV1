### This file contains the information for Group 8 members


|  S\N     | Full Name | Registration Number | Contribution |
| ---      | ---       | ---      | ---       |
| 1 | Nnamani Henry Chukwuemeka   | 2020/244411 | Breakpoint debugging and Programming
| 2 | Ani Peter Benjamin | 2020/241214 | Project Management and Testing
| 3 | Ezeugwu Romanus Chukwuemeka | 2020/242532 | Github cleanup|
| 4 | Ihejirika Tochukwu Daniel  | 2020/241834 | Code Review and Debugging|
| 5 | Ogbu Trisha Chizoba | 2020/241143 | Code Review |
| 6 | Urama Goodness Ezechinemereihe | 2020/244419 | Code Review |
| 7 | Njoku Chukwuemeka | 2020/244400 | Programming and Debugging|
| 8 | Atuanya David Chiagozie  | 2020/244380 | Code Review and Debugging|
| 9 | Ugwu Victor Chidiebere   | 2020/244358 | Code Review and Report |
| 10| Ukachi Amarachi Mary-Grace| 2020/242918 | Code Review|
| 11| Dickson Gift Onu | 2020/243910 | Code Review|
| 12 | Efughi Precious Chidera | 2020/244378 | Code Review |
| 13| Ugwuishiwu Nehemiah Chiemerie | 2020/244323 | Code Review|
| 14| Eze Precious Tochi | 2020/244319 |
| 15 | Mbaeze Victor Onyedika | 2020/244320 | Code Review 
| 16| Ibebeuike Nzube Kennedy | 2020/243025 |
| 17 | Ezeokeke Chukwuebuka Micheal| 2020/241190 | Programming and GitHub Cleanup 
| 18 | Aliozor Chidindu Micheal | 2020/244429 | Code Refactor
| 19 | Nduka John Sobechukwu | 2020/244336 | Code Review and Testing 
|20  | Nwobodo Emmanuel Chimnadindu | 2020/244318 | Code Review and Testing
|21 | Odibelu chino so Mac-Anthony | 2020/247790 | Code Review
|22 | Odoabuchi Lovelyn Nzubechukwu | 2020/248970 | Review Code Report
|23 | Okeke Stanley Ezenwa | 2020/244397 | Code Review

